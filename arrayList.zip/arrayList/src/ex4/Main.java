/*
Crie um programa que deverá ler do usuário uma definição da quantidade de números
que deverão ser adicionados a um ArrayList de inteiros. Após a definição, gere
aleatoriamente esta quantidade números (limitada entre 1 – 100) e armazene em um
ArrayList. Por fim, imprima o ArrayList na ordem original e depois ORDENE o
ArrayList e imprima-o em ordem crescente e decrescente. Dica: pesquisa sobre os
métodos : Collections.sort e reverse();
DESAFIO: Garanta que os elementos da lista sejam TODOS distintos entre si.
 */
package ex4;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Integer> lista = new ArrayList();
        Random rand = new Random();
        System.out.println("defina uma quantidade de numeros: ");
        int quantidade = input.nextInt();       
        for(int i = 0; i < quantidade; i++){
            lista.add(rand.nextInt(101));           
        }
        for(int i = 0; i<quantidade;i++){
            System.out.println(lista.get(i));           
        }
        
        

    }

}
