package ex2;

import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<String> Telefone = new ArrayList();

        int opcao;
        int contador = 0;
        String telefone;
        do {
            System.out.println("(1) Adicionar Telefone");
            System.out.println("(2) Remover Telefone");
            System.out.println("(3) Listar Telefone");
            System.out.println("(0) Sair");
            System.out.print("Escolha uma opcao: ");
            opcao = input.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite um telefone:");
                    telefone = input.next(); 
                    Telefone.add(telefone);
                    contador = contador + 1;
                    break;       
                case 2:
                    for(int i = 0; i < contador;i++){
                        System.out.println("Posicaoo ["+i+"]" + Telefone.get(i));
                    }
                        System.out.println("digite a posicao do telefone a ser removida");
                        int posicao = input.nextInt();
                        Telefone.remove(posicao);
                    
                    break;      
                case 3:
                    System.out.println(Telefone);
                    break;             
                case 0:
                    opcao = 0;
                    
                    break;
                default:
                    System.out.println("\nOpção inválida. Tente novamente.\n");
                    break;
            }
        } while (opcao != 0);
    }
}