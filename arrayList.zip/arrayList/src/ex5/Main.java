package ex5;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Agenda agenda = new Agenda();

        while (true) {
            System.out.println("\n[ 1 ] Incluir Contato");
            System.out.println("[ 2 ] Excluir Contato");
            System.out.println("[ 3 ] Listar Contatos");
            System.out.println("[ 4 ] Pesquisar Contato");
            System.out.println("[ 5 ] Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            switch (opcao) {
                case 1:
                    System.out.print("Digite o nome do contato: ");
                    String nome = scanner.nextLine();
                    System.out.print("Digite o email do contato: ");
                    String email = scanner.nextLine();
                    System.out.print("Digite o telefone do contato: ");
                    String telefone = scanner.nextLine();
                    agenda.adicionarContato(new Contato(nome, email, telefone));
                    System.out.println("Contato adicionado com sucesso.");
                    break;
                case 2:
                    System.out.print("Digite o nome do contato a ser excluído: ");
                    String nomeExcluir = scanner.nextLine();
                    agenda.excluirContato(nomeExcluir);
                    break;
                case 3:
                    agenda.listarContatos();
                    break;
                case 4:
                    System.out.print("Digite parte do nome do contato a ser pesquisado: ");
                    String parteNome = scanner.nextLine();
                    for (Contato contato : agenda.getContatos()) {
                        if (contato.getNome().toLowerCase().contains(parteNome.toLowerCase())) {
                            System.out.println(contato);
                        }
                    }
                    break;
                case 5:
                    System.out.println("Encerrando o programa...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}
